# Helpers: Kenny's Helper Module

This repository is a collection of Python3 functions I commonly use for data management, statistics and plotting. This is my first repository designed like a module, so any comments/suggestions to improve the clarity and accessibilty of the files would be appreciated!

This repository **is a work in progress**.

### Dependencies

* matplotlib (version >= 3.3.2)
* scipy (version >= 1.7.2)
* numpy (version >= 1.19.2)
* pandas (version >= 1.2.3)
